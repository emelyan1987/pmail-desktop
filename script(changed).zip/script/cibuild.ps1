.\script\bootstrap.cmd
.\build\node_modules\.bin\grunt ci --gruntfile .\build\Gruntfile.coffee --statck --no-color
